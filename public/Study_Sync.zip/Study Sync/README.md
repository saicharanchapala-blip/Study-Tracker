# Study Sync

A comprehensive, beautifully styled study session tracker with:
- 🍅 Pomodoro timer mode (25m focus / 5m break cycles) & standard stopwatch
- 📊 Subject analytics, weekly goal progress, and session history logs with custom filtering
- 📅 Google Classroom deadline synchronization & task management
- 🎵 Ambient sound generator with binaural beats and nature atmospheres
- 🌙 Light / Dark mode with refined Parliament typography and linen cream palette

## Quick Start
1. Install dependencies:
   ```bash
   npm install
   ```
2. Start development server:
   ```bash
   npm run dev
   ```
3. Open http://localhost:3000 in your browser!
